package com.rippletec.medicine.service;

import com.rippletec.medicine.model.EnterNews;

public interface EnterNewsManager extends IManager<EnterNews> {
    public static final String NAME = "EnterNewsManager";

}
