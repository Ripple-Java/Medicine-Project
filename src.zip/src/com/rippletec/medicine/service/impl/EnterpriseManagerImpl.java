package com.rippletec.medicine.service.impl;

import java.util.LinkedList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.rippletec.medicine.bean.PageBean;
import com.rippletec.medicine.bean.Result;
import com.rippletec.medicine.dao.EnterpriseDao;
import com.rippletec.medicine.dao.FindAndSearchDao;
import com.rippletec.medicine.dao.UserDao;
import com.rippletec.medicine.model.Enterprise;
import com.rippletec.medicine.model.EnterpriseMedicineType;
import com.rippletec.medicine.model.User;
import com.rippletec.medicine.service.EnterpriseManager;
import com.rippletec.medicine.vo.web.BackGroundMedicineVO;
import com.rippletec.medicine.vo.web.EnterpriseInfoVO;

@Service(EnterpriseManager.NAME)
public class EnterpriseManagerImpl extends BaseManager<Enterprise> implements EnterpriseManager{

    @Resource(name=EnterpriseDao.NAME)
    private EnterpriseDao enterpriseDao;
    @Resource(name=UserDao.NAME)
    private UserDao userDao;
    
    @Override
    protected FindAndSearchDao<Enterprise> getDao() {
	return this.enterpriseDao;
    }

    @Override
    public List<EnterpriseMedicineType> getEnterMedicineTypes(int id) {
	Enterprise enterprise = find(id);
	if(enterprise == null)
	    return new LinkedList<EnterpriseMedicineType>();
	return new LinkedList<EnterpriseMedicineType>(enterprise.getMedicineTypeEnterprises());
    }

    @Override
    public List<Enterprise> getEnterprise(int size, int type, int currentPage) {
	return findByPage(Enterprise.TYPE, type, new PageBean(currentPage, 0, size));
    }

    @Override
    public void deleteByUser(int id) {
	List<Enterprise> enterprises = findBySql(Enterprise.TABLE_NAME, Enterprise.USER_ID, id);
	if(enterprises == null)
	    return;
	for (Enterprise enterprise : enterprises) {
	    delete(enterprise.getId());
	}
    }

    @Override
    public Enterprise findByUser(User user) {
	List<Enterprise> enterprises = enterpriseDao.findBySql(Enterprise.TABLE_NAME, Enterprise.USER_ID, user.getId());
	return enterprises.get(0);
    }

    @Override
    public Result updateInfo(int enterpriseId, EnterpriseInfoVO vo) {
	Enterprise enterprise = enterpriseDao.find(enterpriseId);
	if(enterprise == null){
	    return new Result(false, "企业信息不存在");
	}
	enterprise.setUpdate(vo);
	enterpriseDao.update(enterprise);
	return new Result(true);
    }

    @Override
    public Result active(int id) {
	Enterprise enterprise = enterpriseDao.find(id);
	if(enterprise == null){
	    return new Result(false, "改企业信息不存在");
	}
	enterprise.setStatus(Enterprise.ON_PUBLISTH);
	User user = enterprise.getUser();
	user.setStatus(User.STATUS_NORMAL);
	userDao.update(user);
	return new Result(true);
    }

    @Override
    public Result block(int id) {
	Enterprise enterprise = enterpriseDao.find(id);
	if(enterprise == null){
	    return new Result(false, "该企业不存在");
	}
	enterprise.setStatus(Enterprise.ON_CLOSE);
	enterpriseDao.update(enterprise);
	return new Result(true);
    }

    @Override
    public Result unblock(int id) {
	Enterprise enterprise = enterpriseDao.find(id);
	if(enterprise == null){
	    return new Result(false, "该企业不存在");
	}
	enterprise.setStatus(Enterprise.ON_PUBLISTH);
	enterpriseDao.update(enterprise);
	return new Result(true);
    }

}
