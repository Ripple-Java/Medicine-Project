package com.rippletec.medicine.service;

import com.rippletec.medicine.model.FeedBackMass;

public interface FeedBackMassManager extends IManager<FeedBackMass> {
    
    public static final String NAME = "FeedBackMassManager";

    boolean addFeedBackMass(FeedBackMass feedBackMass,String account);
}
