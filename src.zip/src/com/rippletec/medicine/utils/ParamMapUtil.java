package com.rippletec.medicine.utils;

public class ParamMapUtil {
    
    public static ParamMap get() {
	return new ParamMap();
    }
}
