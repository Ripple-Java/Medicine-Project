package com.rippletec.medicine.utils;

import org.apache.log4j.Logger;

public class LoggerUtil {
    
    public static final Logger UtilLogger = Logger.getLogger("UtilLog");
   

    public static final Logger ControllerLogger = Logger.getLogger("ControllerLogger");
}
