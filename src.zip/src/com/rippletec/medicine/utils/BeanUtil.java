package com.rippletec.medicine.utils;

public class BeanUtil {
    
 
}
