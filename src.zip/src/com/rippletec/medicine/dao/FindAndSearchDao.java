package com.rippletec.medicine.dao;

public interface FindAndSearchDao<T> extends FindByPageDao<T>, ISearchDao<T> {

}
