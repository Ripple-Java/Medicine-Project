package com.rippletec.medicine.dao;

public interface FindByPageDao<T> extends Dao<T>,IFindByPage<T>{

}
