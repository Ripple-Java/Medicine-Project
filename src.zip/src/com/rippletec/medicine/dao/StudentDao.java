package com.rippletec.medicine.dao;

import com.rippletec.medicine.model.Student;

public interface StudentDao extends FindAndSearchDao<Student>{
	public static final String NAME="StudentDao";
}
