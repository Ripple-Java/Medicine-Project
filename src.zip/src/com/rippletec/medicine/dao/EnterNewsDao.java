package com.rippletec.medicine.dao;

import com.rippletec.medicine.model.EnterNews;

public interface EnterNewsDao extends FindAndSearchDao<EnterNews>{
    
    public static final String NAME = "EnterNewsDao";

}
