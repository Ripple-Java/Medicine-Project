/**
 * 
 */
package com.rippletec.medicine.dao;

import java.util.List;
import java.util.Map;

import org.springframework.orm.hibernate3.HibernateTemplate;

/**
 * @author Liuyi
 *
 */
public interface Dao <T>{
    
    /**
     * Dao层基础delete()方法
     * @param id 需要删除条目的id
     */
    boolean delete(Integer id);
    
    /**
     * Dao层基础find方法
     * @param id 条目id
     * @return 
     */
    T find(Integer id);
    
    List<T> findByParam(String param, Object value);
    
    List<T> findByParam(Map<String, Object> paramMap);
    
    List<T> findBySql(String tableName, Map<String, Object> paramMap);
    
    List<T> findBySql(String tableName, String param, Object value);

    List<T> findAll();
    
    /**
     * Dao层基础save()方法
     * @param model 需要持久化的实体
     * @return id
     */
    Integer save(T model);
    
    /**
     * Dao层基础update方法
     * @param model 更新实体
     */
    void update(T model);
    
    int getCount(String tableName);
	
    int getCount(String tableName, String param, Object value);
    
    int getCount(String tableName, String[] param, Object[] value);
    
    HibernateTemplate getDaoHibernateTemplate();

}
