package com.rippletec.medicine.dao;

import com.rippletec.medicine.model.FeedBackMass;

public interface FeedBackMassDao extends FindAndSearchDao<FeedBackMass> {

    public static final String NAME = "FeedBackMassDao";
}
