/**
 * 
 */
package com.rippletec.medicine.model;

import java.io.Serializable;

import org.springframework.stereotype.Repository;

/**
 * @author Liuyi
 *
 */
@Repository
public class BaseModel implements Serializable{

    private static final long serialVersionUID = -5165515588305763947L;

  
    
}
