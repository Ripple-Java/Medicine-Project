package com.rippletec.medicine.model.extend;

import com.rippletec.medicine.model.User;

public class UserBean extends User{
    
    private static final long serialVersionUID = -5256213216297198007L;
    
    public static final String CLASS_NAME = User.CLASS_NAME;
    
   
}
