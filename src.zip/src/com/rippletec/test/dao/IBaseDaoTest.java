package com.rippletec.test.dao;

public interface IBaseDaoTest {
    
    void testDelete()throws Exception;
    
    void testFind()throws Exception;
    
    void testFindByPage()throws Exception;
    
    void testSave()throws Exception;
    
    void testUpdate()throws Exception;
}
